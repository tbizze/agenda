<template>
  <h2 class="font-semibold text-3xl text-gray-800">
    <slot />
  </h2>
</template>