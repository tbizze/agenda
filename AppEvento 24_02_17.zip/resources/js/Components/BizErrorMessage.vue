<template>
  <p class="mb-1 ml-1 text-sm text-red-600">
    <slot />
  </p>
</template>